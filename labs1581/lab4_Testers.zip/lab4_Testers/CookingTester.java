public class CookingTester
{
	public static void main(String[] args)
	{
		String error;
		error = testTeaspoonToTablespoon();
		if (error != null) { System.out.println(error); return;}
		error = testTablespoonToTeaspoon();
		if (error != null) { System.out.println(error); return;}
		error = testTablespoonToCup();
		if (error != null) { System.out.println(error); return;}
		error = testCupToTablespoon();
		if (error != null) { System.out.println(error); return;}
		error = testouncesToCups();
		if (error != null) { System.out.println(error); return;}
		error = testCupToOunces();
		if (error != null) { System.out.println(error); return;}
		error = testPintToCup();
		if (error != null) { System.out.println(error); return;}
		error = testCupToPint();
		if (error != null) { System.out.println(error); return;}
		System.out.println("Cooking: Correct!");
	}

	public static String testTeaspoonToTablespoon()
	{
		double portion;

		portion = Cooking.teaspoonsToTablespoons(0);
		if (portion != 0.0) return "Cooking.teaspoonsToTablespoons(0)";
		portion = Cooking.teaspoonsToTablespoons(60);
		if (portion != 1.0) return "Cooking.teaspoonsToTablespoons(60)";
		portion = Cooking.teaspoonsToTablespoons(3600);
		if (portion != 60.0) return "Cooking.teaspoonsToTablespoons(3600)";
		portion = Cooking.teaspoonsToTablespoons(999999);
		if (portion != 16666.65) return "Cooking.teaspoonsToTablespoons(999999)";
		return null;
	}

	public static String testTablespoonToTeaspoon()
	{
		double portion;

		portion = Cooking.tablespoonsToTeaspoons(0);
		if (portion != 0.0) return "Cooking.tablespoonsToTeaspoons(0)";
		portion = Cooking.tablespoonsToTeaspoons(60);
		if (portion != 0.016666666666666666) return "Cooking.tablespoonsToTeaspoons(60)";
		portion = Cooking.tablespoonsToTeaspoons(3600);
		if (portion != 1.0) return "Cooking.tablespoonsToTeaspoons(3600)";
		portion = Cooking.tablespoonsToTeaspoons(999999);
		if (portion != 277.77750000000003) return "Cooking.getportionCirlce(999999)";
		return null;
		
	}

	public static String testTablespoonToCup()
	{
		double portion;

		portion = Cooking.tablespoonsToCups(0);
		if (portion != 0) return "Cooking.tablespoonsToCups(0)";
		portion = Cooking.tablespoonsToCups(60);
		if (portion != 6.944444444444445E-4) return "Cooking.tablespoonsToCups(60)";
		portion = Cooking.tablespoonsToCups(3600);
		if (portion != 0.041666666666666664) return "Cooking.tablespoonsToCups(3600)";
		portion = Cooking.tablespoonsToCups(999999);
		if (portion != 11.574062500000002) return "Cooking.tablespoonsToCups(999999)";
		return null;
	}

	public static String testCupToTablespoon()
	{
		double portion;

		portion = Cooking.cupsToTablespoons(0);
		if (portion != 0.0) return "Cooking.cupsToTablespoons(0)";
		portion = Cooking.cupsToTablespoons(60);
		if (portion != 1.9025875190258753E-6) return "Cooking.cupsToTablespoons(60)";
		portion = Cooking.cupsToTablespoons(3600);
		if (portion != 1.1415525114155251E-4) return "Cooking.cupsToTablespoons(3600)";
		portion = Cooking.cupsToTablespoons(999999);
		if (portion != 0.031709760273972605) return "Cooking.cupsToTablespoons(999999)";
		return null;
	}

	public static String testouncesToCups()
	{
		double portion;

		portion = Cooking.ouncesToCups(1);
		if (portion != 60.0) return "Cooking.ouncesToCups(1)";
		portion = Cooking.ouncesToCups(60);
		if (portion != 3600.0) return "Cooking.ouncesToCups(60)";
		portion = Cooking.ouncesToCups(3600);
		if (portion != 216000.0) return "Cooking.ouncesToCups(3600)";
		portion = Cooking.ouncesToCups(999999);
		if (portion != 5.999994E7) return "Cooking.getportionCirlce(999999)";
		return null;
	}

	public static String testCupToOunces()
	{
		double portion;

		portion = Cooking.cupsToOunces(1);
		if (portion != 3600.0) return "Cooking.cupsToOunces(1)";
		portion = Cooking.cupsToOunces(60);
		if (portion != 216000.0) return "Cooking.cupsToOunces(60)";
		portion = Cooking.cupsToOunces(3600);
		if (portion != 1.296E7) return "Cooking.cupsToOunces(3600)";
		portion = Cooking.cupsToOunces(999999);
		if (portion != 3.5999964E9) return "Cooking.cupsToOunces(999999)";
		return null;
	}

	public static String testPintToCup()
	{
		double portion;

		portion = Cooking.pintsToCups(1);
		if (portion != 86400.0) return "Cooking.pintsToCups(1)";
		portion = Cooking.pintsToCups(60);
		if (portion != 5184000.0) return "Cooking.pintsToCups(60)";
		portion = Cooking.pintsToCups(3600);
		if (portion != 3.1104E8) return "Cooking.pintsToCups(3600)";
		portion = Cooking.pintsToCups(999999);
		if (portion != 8.63999136E10) return "Cooking.pintsToCups(999999)";
		return null;
	}

	public static String testCupToPint()
	{
		double portion;

		portion = Cooking.cupsToPints(1);
		if (portion != 3.1536E7) return "Cooking.cupsToPints(1)";
		portion = Cooking.cupsToPints(60);
		if (portion != 1.89216E9) return "Cooking.cupsToPints(60)";
		portion = Cooking.cupsToPints(3600);
		if (portion != 1.135296E11) return "Cooking.cupsToPints(3600)";
		portion = Cooking.cupsToPints(999999);
		if (portion != 3.1535968464E13) return "Cooking.cupsToPints(999999)";
		return null;
	}




}
