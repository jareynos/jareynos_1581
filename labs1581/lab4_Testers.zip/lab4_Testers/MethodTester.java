/*
Notes:
instead of for loop across all methods
parameter on input file should be the method name
and number of arguments for that method
this way we can run a method at a time
testing each for validity and error messaging if
a single method gets it wrong
*/

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Scanner;
import java.util.Arrays;


public class MethodTester
{
	private static Scanner input = new Scanner(System.in);

	public static void main(String[] args)
	{
		int cases = input.nextInt();
		for (int test=0; test<cases; test++)
		{
			executeMethod();
		}
	}

	public static void executeMethod()
	{

		//Use scanner object to grab series of inputs for each method
		//build string that will insert data invoke.

		try
		{
			String className = input.next();			
			Class<?> classData = Class.forName(className);
			//System.out.println(classData);
			
			//Method[] allMethods = classData.getDeclaredMethods();
			String methodName = input.next();

			int count = input.nextInt();

			Class[] types = new Class[count]; //{double.class};
			for (int i=0; i<count; i++)
			{
				String type = input.next();
				switch(type)
				{
					case "int": types[i] = int.class; break;
					case "double": types[i] = double.class; break;
					case "boolean": types[i] = boolean.class; break;
					case "String": types[i] = java.lang.String.class; break;
				}
			}
			Method method = classData.getDeclaredMethod(methodName, types);//double.class); //int.class);
			//for ( Method method : allMethods)
			//{
				//System.out.println(method);
				//String methodName = method.getName();
				method.setAccessible(true);
				int param_qty = method.getParameterCount();
				Object[] params = new Object[param_qty];
				/*for (int i=0; i<param_qty; i++)
				{
					var value = input.nextInt();
					params[i] = value;//input.nextDouble();
				}*/
				int i = 0;
				for (Type type : method.getGenericParameterTypes())
				{
					String datatype = type.toString();
					switch(datatype)
					{
						case "int": params[i] = input.nextInt(); break;
						case "double": params[i] = input.nextDouble(); break;
					}
					i++;
				}
				var result = method.invoke(classData, params);
				System.out.printf("%s(%s)=%s\n",method.getName(), Arrays.toString(params).replace("[", "").replace("]", ""),result);
				
				/*for ( Type t : method.getGenericParameterTypes())
				{
					System.out.println(t);
				}*/
			//}
		}
		catch (ClassNotFoundException e) 
		{
	    	e.printStackTrace();
		}
		catch (IllegalAccessException e) 
		{
	    	e.printStackTrace();
		}
		catch (InvocationTargetException e) 
		{
	    	e.printStackTrace();
		}
		catch (NoSuchMethodException e) 
		{
	    	e.printStackTrace();
		}
	}
}