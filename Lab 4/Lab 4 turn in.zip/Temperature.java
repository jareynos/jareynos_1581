public class Temperature{
public static double celsiusToFahrenheit(double celsius){
double cel = celsius; // created a local varible
double result = (9.0/5.0) * cel + 32;
return result; // return value computed
}
public static double celsiusToKelvin(double celsius){
double result = celsius + 273.15; // using paramter as varible
return result;
}
public static double fahrenheitToCelsius(double fahrenheit){
double fah = fahrenheit;
double result = (5.0/9.0) * (fah - 32);
return result;
}
public static double fahrenheitToKelvin(double fahrenheit){
double result = (5.0/9.0) * (fahrenheit + 459.67);
return result;
}
public static double kelvinToFahrenheit(double kelvin){
double result = (9.0/5.0) * kelvin - 459.67;
return result;
}
public static double kelvinToCelsius(double kelvin){
return kelvin - 273.15;
}
}